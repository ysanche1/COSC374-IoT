package gateway_simulation;

public class ThermostatCloud extends DeviceCloud {
    public void soundOff(){
        System.out.println("Request handled by Thermostat Cloud");
    }
}