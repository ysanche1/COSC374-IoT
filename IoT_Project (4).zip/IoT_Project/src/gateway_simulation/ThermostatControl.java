package gateway_simulation;


import javax.swing.*;
import java.awt.*;
import java.security.PublicKey;
import javax.swing.border.*;
import com.intellij.uiDesigner.core.*;


public class ThermostatControl extends JFrame implements Runnable{
    static Thermostat thermostat;
    AESAlgorithm aes;
    String aesKey;
    PublicKey gatewayPublicKey;
    AttackSim atk;

    public ThermostatControl(){
        initComponents();
    }

public void initialize(String aesKey, Message replayMessage, Message finalMessage) throws Exception {
    atk = new AttackSim(replayAttackButton, suspiciousActionButton, cloudCrash, replayMessage);
    this.aesKey = aesKey;
        aes = new AESAlgorithm(aesKey);
        gatewayPublicKey = Main.app.rsaK.strToKey(aes.decrypt(finalMessage.pub_key));
        Main.app.rsaE = new RSAAlgorithm(gatewayPublicKey);
        this.aesKey = aes.decrypt(finalMessage.key);
        thermostat = new Thermostat();
        String increase = "INCREASE";
        String decrease = "DECREASE";
        String custom = "CUSTOM";
        Main.gateway.initialize(thermostat);
    setContentPane(panel1);
    setTitle("Thermostat Controller");
    setResizable(false);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    pack();
    getRootPane().setDefaultButton(customButton);
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); // put the window in a nice spot
    int frameX = (screenSize.width / 2) - (getWidth() / 2);             //
    int frameY = (screenSize.height / 2) - (getHeight());;                                 //
    setLocation(frameX, frameY);
    setVisible(true);
    thermostat.main();
    increaseButton.addActionListener(e -> {
        try {
            newRequest(increase, "");
        } catch (Exception interruptedException) {
            interruptedException.printStackTrace();
        }
    });
    decreaseButton.addActionListener(e -> {
        try {
            newRequest(decrease,"");
        } catch (Exception interruptedException) {
        }
    });
    customButton.addActionListener(e -> {
        int customTemp = 0;
        try {
           customTemp = Integer.parseInt(customTempField.getText());
           newRequest(custom, String.valueOf(customTemp));
        }
        catch (NumberFormatException nfe) {
            updateField.setText("Non-numeric Value entered");
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    });
}
    private void newRequest(String command, String custom) throws Exception {

        customTempField.setText("");
        aes = new AESAlgorithm(aesKey);
        Message m = new Message(command, custom);
        aes.encryptMessage(m);
        m.key = Main.app.rsaE.encrypt(aesKey);
        m.key = Main.app.rsaE.encrypt(aesKey);
        Main.gateway.relayRequest(m, thermostat);
    }

    public void receiveResponse(Message m) throws Exception {
        aesKey = Main.app.rsaD.decrypt(m.key);
        atk.aesKey = aesKey;
        atk.captureSymmetricKey(aesKey);
        aes = new AESAlgorithm(aesKey);
        if(m.error == true) {
            increaseButton.setEnabled(false);
            decreaseButton.setEnabled(false);
            customButton.setEnabled(false);
            updateField.setText(aes.decrypt(m.update));
        }
        else
            updateField.setText(aes.decrypt(m.update));
    }

    public void subscribe(Message m) throws Exception {
    tempDisplay.setText(Main.app.rsaD.decrypt(m.update)+"\u00B0");
    }

    public void setNotification(String s){
    gatewayNotification.setText(s);
    }

    @Override
    public void run() {

    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner Evaluation license - unknown
        panel1 = new JPanel();
        var panel2 = new JPanel();
        topPanel = new JPanel();
        space = new JPanel();
        headerPanel = new JPanel();
        updateField = new JLabel();
        var panel3 = new JPanel();
        tempDisplay = new JLabel();
        var panel4 = new JPanel();
        increaseButton = new JButton();
        var panel5 = new JPanel();
        decreaseButton = new JButton();
        var panel6 = new JPanel();
        tempDisplayPanel = new JPanel();
        customTempField = new JTextField();
        customButton = new JButton();
        var panel7 = new JPanel();
        gatewayNotification = new JLabel();
        var panel8 = new JPanel();
        cloudCrash = new JButton();
        suspiciousActionButton = new JButton();
        replayAttackButton = new JButton();

        //======== panel1 ========
        {
            panel1.setBorder ( new javax . swing. border .CompoundBorder ( new javax . swing. border .TitledBorder ( new javax . swing.
            border .EmptyBorder ( 0, 0 ,0 , 0) ,  "JF\u006frmD\u0065sig\u006eer \u0045val\u0075ati\u006fn" , javax. swing .border . TitledBorder. CENTER
            ,javax . swing. border .TitledBorder . BOTTOM, new java. awt .Font ( "Dia\u006cog", java .awt . Font
            . BOLD ,12 ) ,java . awt. Color .red ) ,panel1. getBorder () ) ); panel1. addPropertyChangeListener(
            new java. beans .PropertyChangeListener ( ){ @Override public void propertyChange (java . beans. PropertyChangeEvent e) { if( "\u0062ord\u0065r"
            .equals ( e. getPropertyName () ) )throw new RuntimeException( ) ;} } );
            panel1.setLayout(new GridBagLayout());

            //======== panel2 ========
            {
                panel2.setBorder(new TitledBorder(new EtchedBorder(), "Thermostat  Control"));
                panel2.setLayout(new GridLayoutManager(4, 5, new Insets(0, 0, 0, 0), -1, -1));

                //======== topPanel ========
                {
                    topPanel.setLayout(new GridBagLayout());

                    //======== space ========
                    {
                        space.setLayout(new GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));
                    }
                    topPanel.add(space, new GridBagConstraints(0, 0, 1, 1, 0.65, 0.3,
                        GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                        new Insets(0, 0, 0, 0), 0, 0));

                    //======== headerPanel ========
                    {
                        headerPanel.setLayout(new GridLayoutManager(1, 1, new Insets(0, 0, 0, 10), -1, -1));

                        //---- updateField ----
                        updateField.setText("Awaiting Request");
                        headerPanel.add(updateField, new GridConstraints(0, 0, 1, 1,
                            GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_NONE,
                            GridConstraints.SIZEPOLICY_FIXED,
                            GridConstraints.SIZEPOLICY_FIXED,
                            null, null, null));
                    }
                    topPanel.add(headerPanel, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.3,
                        GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                        new Insets(0, 0, 0, 0), 0, 0));

                    //======== panel3 ========
                    {
                        panel3.setLayout(new GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));

                        //---- tempDisplay ----
                        tempDisplay.setText("00\u00b0F");
                        panel3.add(tempDisplay, new GridConstraints(0, 0, 1, 1,
                            GridConstraints.ANCHOR_EAST, GridConstraints.FILL_NONE,
                            GridConstraints.SIZEPOLICY_FIXED,
                            GridConstraints.SIZEPOLICY_FIXED,
                            null, null, null));
                    }
                    topPanel.add(panel3, new GridBagConstraints(2, 0, 1, 1, 0.5, 0.0,
                        GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                        new Insets(0, 0, 0, 0), 0, 0));
                }
                panel2.add(topPanel, new GridConstraints(0, 0, 1, 5,
                    GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH,
                    GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                    GridConstraints.SIZEPOLICY_FIXED,
                    null, null, null));

                //======== panel4 ========
                {
                    panel4.setLayout(new GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));

                    //---- increaseButton ----
                    increaseButton.setText("Increase");
                    panel4.add(increaseButton, new GridConstraints(0, 0, 1, 1,
                        GridConstraints.ANCHOR_SOUTH, GridConstraints.FILL_HORIZONTAL,
                        GridConstraints.SIZEPOLICY_FIXED,
                        GridConstraints.SIZEPOLICY_FIXED,
                        null, null, null));
                }
                panel2.add(panel4, new GridConstraints(1, 0, 2, 2,
                    GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH,
                    GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                    GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                    null, null, null));

                //======== panel5 ========
                {
                    panel5.setLayout(new GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));

                    //---- decreaseButton ----
                    decreaseButton.setText("Decrease");
                    panel5.add(decreaseButton, new GridConstraints(0, 0, 1, 1,
                        GridConstraints.ANCHOR_SOUTH, GridConstraints.FILL_HORIZONTAL,
                        GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                        GridConstraints.SIZEPOLICY_FIXED,
                        null, null, null));
                }
                panel2.add(panel5, new GridConstraints(1, 2, 2, 3,
                    GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH,
                    GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                    GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                    null, null, null));

                //======== panel6 ========
                {
                    panel6.setLayout(new GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));

                    //======== tempDisplayPanel ========
                    {
                        tempDisplayPanel.setLayout(new GridBagLayout());

                        //---- customTempField ----
                        customTempField.setText("");
                        tempDisplayPanel.add(customTempField, new GridBagConstraints(0, 0, 3, 1, 1.0, 1.0,
                            GridBagConstraints.SOUTH, GridBagConstraints.HORIZONTAL,
                            new Insets(0, 0, 0, 0), 0, 0));

                        //---- customButton ----
                        customButton.setText("Custom");
                        tempDisplayPanel.add(customButton, new GridBagConstraints(1, 1, 1, 1, 1.0, 1.0,
                            GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL,
                            new Insets(0, 100, 0, 100), 0, 0));
                    }
                    panel6.add(tempDisplayPanel, new GridConstraints(0, 0, 1, 1,
                        GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH,
                        GridConstraints.SIZEPOLICY_CAN_GROW,
                        GridConstraints.SIZEPOLICY_FIXED,
                        null, null, null));
                }
                panel2.add(panel6, new GridConstraints(3, 0, 1, 5,
                    GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH,
                    GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                    GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                    null, null, null));
            }
            panel1.add(panel2, new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                new Insets(0, 0, 0, 0), 0, 0));

            //======== panel7 ========
            {
                panel7.setBorder(new TitledBorder(new EmptyBorder(7, 0, 5, 0), ""));
                panel7.setLayout(new GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));

                //---- gatewayNotification ----
                gatewayNotification.setText("Login successful");
                panel7.add(gatewayNotification, new GridConstraints(0, 0, 1, 1,
                    GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_VERTICAL,
                    GridConstraints.SIZEPOLICY_FIXED,
                    GridConstraints.SIZEPOLICY_FIXED,
                    null, null, null));
            }
            panel1.add(panel7, new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                new Insets(0, 0, 0, 0), 0, 0));

            //======== panel8 ========
            {
                panel8.setBorder(new TitledBorder(new EtchedBorder(), "Attack Simulation"));
                panel8.setLayout(new GridLayoutManager(1, 3, new Insets(0, 0, 0, 0), -1, -1));

                //---- cloudCrash ----
                cloudCrash.setText("Cloud Crash");
                panel8.add(cloudCrash, new GridConstraints(0, 2, 1, 1,
                    GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_NONE,
                    GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                    GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                    null, null, null));

                //---- suspiciousActionButton ----
                suspiciousActionButton.setText("Suspicious Action");
                panel8.add(suspiciousActionButton, new GridConstraints(0, 1, 1, 1,
                    GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_NONE,
                    GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                    GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                    null, null, null));

                //---- replayAttackButton ----
                replayAttackButton.setText("Replay Attack");
                panel8.add(replayAttackButton, new GridConstraints(0, 0, 1, 1,
                    GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_NONE,
                    GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                    GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_CAN_GROW,
                    null, null, null));
            }
            panel1.add(panel8, new GridBagConstraints(0, 3, 1, 1, 1.0, 1.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                new Insets(0, 0, 0, 0), 0, 0));
        }
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner Evaluation license - unknown
    private JPanel panel1;
    private JPanel topPanel;
    private JPanel space;
    private JPanel headerPanel;
    private JLabel updateField;
    private JLabel tempDisplay;
    private JButton increaseButton;
    private JButton decreaseButton;
    private JPanel tempDisplayPanel;
    private JTextField customTempField;
    private JButton customButton;
    private JLabel gatewayNotification;
    private JButton cloudCrash;
    private JButton suspiciousActionButton;
    private JButton replayAttackButton;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}


