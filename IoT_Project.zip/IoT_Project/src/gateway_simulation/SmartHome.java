package gateway_simulation;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class SmartHome {

    public SmartHome (){

  //  app.addPropertyChangeListener(gateway);
   // app.addPropertyChangeListener(kdc);
}
}

