package gateway_simulation;


import java.security.PrivateKey;
import java.security.PublicKey;

public class Main extends Thread {
    public static Gateway gateway = new Gateway();
    public static CloudMonitor cloudMonitor = new CloudMonitor(gateway.cloudBackup);
    public static ThermostatControl tc = new ThermostatControl();
    public static App app;
    public static ThermostatCloud tcCloud = new ThermostatCloud();
    public static Kerberos kdc;
    static Login login;
    static PublicKey gwPublicKey;
    static boolean loggedIn;
    static PublicKey appPublicKey;
    static PublicKey gatewayPublicKey;
    static PrivateKey appPrivateKey;
    static RSAAlgorithm rsaE;
    static RSAAlgorithm rsaD;
    static RSAKeyPairGenerator rsaK;

    public static void main(String[] args) throws Exception {
        login = new Login();
        Thread monitor = new Thread(cloudMonitor);
        Thread loginThread = new Thread(login);
        kdc = new Kerberos();
        rsaK = new RSAKeyPairGenerator();
        appPublicKey = rsaK.getPublicKey();
        appPrivateKey = rsaK.getPrivateKey();
        rsaD = new RSAAlgorithm(appPrivateKey);
        loginThread.start();
        monitor.start();
        while(!cloudMonitor.loggedIn){
            Thread.sleep(500);
        }

    }
}