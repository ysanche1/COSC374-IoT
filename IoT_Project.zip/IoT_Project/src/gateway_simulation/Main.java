package gateway_simulation;

import javax.naming.event.NamingEvent;
import javax.naming.event.NamingExceptionEvent;
import javax.naming.event.ObjectChangeListener;
import javax.swing.JFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;


public class Main extends Thread {

    public static void main(String[] args) throws InterruptedException, NoSuchAlgorithmException {
        PublicKey gwPublicKey;
        System.out.print("Main Thread : ");
        Gateway gateway = new Gateway();
        Kerberos kdc = new Kerberos(gateway);
        App app = new App(kdc);
        Thread appThread = new Thread(app);
        Thread loginThread = new Thread(app.login);
        loginThread.start();
        appThread.start();


        System.out.println("Awaiting User Verification");
        while(!app.login.ticketRetrieved)
        {
            Thread.sleep(100);
        }



        Message sgt = app.sgtRetrieval();
        gwPublicKey = gateway.checkMessage(sgt).pk;
        ThermostatControl tc = new ThermostatControl(gwPublicKey);




    }
}

