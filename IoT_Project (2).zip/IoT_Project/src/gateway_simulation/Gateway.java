package gateway_simulation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowEvent;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

public class Gateway extends JFrame implements Runnable{
    String gatewayID = "gateway374";
    private String sharedKey;
    String keyTGS_V = "TGS_V_SHAREDKEY+";
    private JPanel mainPanel;
    private JLabel awaitingLogin;
    String ticketContents;
    Message message;
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    int frameX; int frameY;
    GatewayWaiting gw;
    RSAKeyPairGenerator rsa;
    PublicKey publicKey;
    PrivateKey privateKey;
    Thermostat thermostat;

public Gateway(){
    try {
        generateKeyPair();
    } catch (NoSuchAlgorithmException e) {
        e.printStackTrace();
    }
    gw = new GatewayWaiting();
}


    private void generateKeyPair() throws NoSuchAlgorithmException {
        rsa = new RSAKeyPairGenerator();
        publicKey=rsa.getPublicKey();
        privateKey=rsa.getPrivateKey();
    }

    public Message checkMessage(Message m){
        if(m.mNum == 5)
        {
            gw.dispatchEvent(new WindowEvent(gw, WindowEvent.WINDOW_CLOSING));
            message = m;
            m.displayContents();
            sharedKey = m.key;
        }
        return sendPublicKey(m);
    }

    void initialize(){
        thermostat = new Thermostat();
        Thread t = new Thread(thermostat, "Thermostat thread");
        setTitle("Gateway");
        setContentPane(mainPanel);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();                                                             // put the window in a nice spot
        frameX = (screenSize.width / 2) - (getWidth() / 2);             //
        frameY = (screenSize.height / 2) - (getHeight()*7/2);;
        setLocation(frameX, frameY);                //
        setVisible(true);
        t.start();
    }

    private Message sendPublicKey(Message m){
        m.createPublicKeyMessage(publicKey);
        return m;
    }


    public void receiveRequest(ThermostatControl.Command c, String custom,  Thermostat t) throws InterruptedException {
 //     System.out.println(Thread.currentThread());
        System.out.println("Request at gateway");
        t.receiveRequest(c, custom);
    }

    @Override
    public void run() {
        initialize();
    }
}