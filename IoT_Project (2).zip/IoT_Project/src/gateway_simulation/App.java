package gateway_simulation;

import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

public class App{


    public App(Kerberos kdc) throws NoSuchAlgorithmException {

    }


    }


