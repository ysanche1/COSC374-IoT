package gateway_simulation;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.PublicKey;


public class ThermostatControl extends JFrame implements Runnable{
    int newTemp = 0;
    private PublicKey gwPK;
    Gateway gateway;
    Thread gwt = new Thread(gateway);
    private JPanel panel1;
    private JButton increaseButton;
    private JButton decreaseButton;
    private JTextField customTempField;
    private JButton customButton;
    private JLabel header;
    @Override
    public void run() {
    }

    enum Command {INCREASE, DECREASE, CUSTOM}

public ThermostatControl(PublicKey gwPK){
        this.gwPK = gwPK;
        this.gateway = gateway;
        Command increase = Command.INCREASE;
        Command decrease = Command.DECREASE;
        Command custom = Command.CUSTOM;
        Thread gwt = new Thread(gateway);
    gwt.start();
        setContentPane(panel1);
    setTitle("Thermostat Controller");
    setResizable(false);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    pack();
    getRootPane().setDefaultButton(customButton);
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); // put the window in a nice spot
    int frameX = (screenSize.width / 2) - (getWidth() / 2);             //
    int frameY = (screenSize.height / 2) - (getHeight());;                                 //
    setLocation(frameX, frameY);                                        //
    setVisible(true);
    increaseButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                newRequest(increase, "");
            } catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            }
        }
    });
    decreaseButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                newRequest(decrease,"");
            } catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            }
        }
    });
    customButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                newRequest(custom,customTempField.getText());
            } catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            }
        }
    });
}


    private void newRequest(Gateway g,Command command, String custom) throws InterruptedException {
        g.receiveRequest(command, custom, gateway.thermostat);
    }
}


